import java.util.Collection;

public interface Ukoly {
	
	void pridatUkol(Ukol ukol);
	Collection najdiUkol(String nazev);
	

}
