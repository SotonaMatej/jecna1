package V�pis;

public class S�ly {
// Zde budou jednotliv� s�ly kina a jejich rozvrh film�.
}
