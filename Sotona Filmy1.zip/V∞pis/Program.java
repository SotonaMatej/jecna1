package V�pis;

public class Program {
// Zde bude info o filmu a program kina.
}
