
package V�pis;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
// Zde to budu v�e volat.
	}

}
