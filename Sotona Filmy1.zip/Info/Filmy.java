package Info;

public class Filmy {
// Zde bude seznam film�. Filmy budou obsahovat informace o herc�ch, kter�ch ve filmu hraj� a jak� je to ��nr.
}
