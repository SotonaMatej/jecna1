package Info;

public class Kina {
// Zde bude adresa kina a po�et s�l�, kter� maj� k dispozici.
}
